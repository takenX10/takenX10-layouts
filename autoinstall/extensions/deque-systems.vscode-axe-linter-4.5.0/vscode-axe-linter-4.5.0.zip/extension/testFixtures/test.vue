<template>
  <div class="AriaRoleFailed">
    <div role="datepicker"></div>
    <div role="range"></div>
    <img />
  </div>
</template>

<script>
export default {
  name: 'AriaRole',
  props: {
    role: String
  }
}
</script>
