import React from 'react'

const Image = () => (
  <div>
    <img src="" className="center" />
  </div>
)

export default Image
